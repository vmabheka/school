#!/bin/bash
# Excel Group of Schools - Management System
# Startup Script for Linux/Mac
# =====================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo ""
echo "============================================================"
echo "  Excel Group of Schools - School Management System"
echo "  Startup Script v1.0.0"
echo "============================================================"
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is not installed."
    echo "Please install Python 3.8 or higher from https://python.org"
    exit 1
fi

echo "Python version: $(python3 --version)"

# Check/install dependencies
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

echo "Activating virtual environment..."
source venv/bin/activate

echo "Installing dependencies..."
pip install -q -r requirements.txt

# Initialize database if not exists
if [ ! -f "excel_schools.db" ]; then
    echo "Initializing database..."
    python3 -c "from app import app, init_db; app.app_context().push(); init_db()"
fi

# Start the server
echo ""
echo "Starting server..."
echo "Access the system at: http://localhost:5000"
echo "Default login: admin / admin123"
echo "Press Ctrl+C to stop the server."
echo ""

python3 run.py "$@"
